﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HowToReceiveMessages
{
    public class ListaPrecioDetalle
    {
        public string Sku { get; set; }
        public decimal PrecioContado { get; set; }
        public decimal PrecioCredito { get; set; }
    }
}
